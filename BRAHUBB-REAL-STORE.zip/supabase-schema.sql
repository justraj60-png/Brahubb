-- BRAHUBB database schema for Supabase
create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null,
  price numeric(12,2) not null,
  mrp numeric(12,2),
  image text,
  rating numeric(3,2) default 4.2,
  reviews integer default 0,
  active boolean default true,
  created_at timestamptz default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_no text unique not null,
  customer_name text not null,
  phone text not null,
  address text not null,
  total numeric(12,2) not null,
  status text not null default 'pending',
  items jsonb not null,
  created_at timestamptz default now()
);

alter table public.products enable row level security;
alter table public.orders enable row level security;

-- Storefront can read active products.
drop policy if exists "public read active products" on public.products;
create policy "public read active products" on public.products
for select using (active = true);

-- Storefront can create orders.
drop policy if exists "public create orders" on public.orders;
create policy "public create orders" on public.orders
for insert with check (true);

-- IMPORTANT: For production, do NOT expose an admin service key in the browser.
-- The simple admin page included here is a setup/demo panel. Before accepting real
-- customer data at scale, protect admin access with Supabase Auth and admin RLS policies.
